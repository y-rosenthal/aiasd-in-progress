# My Awesome Project

This is a simple website project to learn Git!

## What it does

A personal portfolio website.
